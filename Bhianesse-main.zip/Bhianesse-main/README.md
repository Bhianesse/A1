<div align="center">
    <a href="https://github.com/kawarimidoll/typograssy">
        <img alt="typograssy" src="https://typograssy.deno.dev/api?text=%E3%83%A0%E3%83%8F%E3%83%B3%E3%83%9E%E3%83%89%E3%83%BB%E3%83%95%E3%82%A1%E3%83%AB%E3%83%8F%E3%83%B3%E3%83%BB%E3%83%8A%E3%82%BA%E3%82%AB%E3%83%A0%E3%83%BB%E3%82%A2%E3%83%AB%E3%83%93%E3%82%A2%E3%83%B3%E3%82%B7%E3%83%A3&l0=000000&l1=0000ff&l2=00ffff&l3=00ffff&l4=00ffff&bg=000000&frame=ff00ff&speed=50&comment=">
    </a>
    <p>
        <img draggable="false"style="witdh:119xp;height:20xp;" src="https://komarev.com/ghpvc/?username=Bhianesse&style=for-the-badge&color=1C8C8C">
        <a href="https://t.me/bhianchat_bot">
            <img  draggable="false" style="witdh:119xp;height:20xp;"src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white">
        </a>
    </p>
</div>

<br>

<div align="center">
    <img src="https://media.tenor.com/fvj5ZjZIn9MAAAAi/hi-hello.gif" width="300px">
</div>

<br>

<h2 align="center"> 👁️‍🗨️ About me 👁️‍🗨️ </h2>
Muhammad Farhan Nazkham Albhiansyah

<div>
    <br>
    <br>
    <br>
    <br>
    <p align="right">
        <a href = "https://www.youtube.com/watch?v=Sfz5TpCRSiI">
            <img src = "https://i.ytimg.com/vi/Sfz5TpCRSiI/maxresdefault.jpg" width = "170" align = "right">
        </a>
       <b>ずっと真夜中でいいのに🎶「猫リセット」。🐱 ⏪<br><br></b>
    </p>
    <br>
    <br>
    <p align="right">
        <a href = "https://www.youtube.com/watch?v=ziZX0vy8xAM">
            <img src = "https://i.ytimg.com/vi/ziZX0vy8xAM/maxresdefault.jpg" width = "170" align = "left">
        </a>
        <b>奏(かなで)CV:高橋李依とCV:雨宮天<br>🎵ふたりはいつもどんな時もつながっていける。🎵</b>
    </p>
    <br>
    <br>
    <p align="left">
        <a href = "https://www.youtube.com/watch?v=oXlEEXws3gc">
            <img  src ="https://i.ytimg.com/vi/oXlEEXws3gc/maxresdefault.jpg" width="170" align="right">
        </a>
        <b><br><br>高橋李依🎶「共感されなくてもいいじゃない」。🎶🆙</b>
    </p>
    <br>
    <br>
    <p align="right">
        <a href="https://www.youtube.com/watch?v=jC97suFyObw">
            <img src="https://i.ytimg.com/vi/jC97suFyObw/maxresdefault.jpg" width="170" align="left">
        </a>
        <b><br>雨宮天🎶「ロンリーナイト・ディスコティック」。🎶💌</b></p>
    <br>
    <br>
    <p align="left">
    <a href="https://youtu.be/b_cuMcDWwsI?si=od4QcDPpNVk">
        <img src="https://i.ytimg.com/vi/od4QcDPpNVk/hqdefault.jpg" width="170" align="right">
    </a>
    <b><br>かめりあ - ヒアソビ (feat. 初音ミク) 【Electroswing】💘🪄💕</b>
    </p>
</div>

<br>
<br>
<br>

<div>
    <h2 align="center"> 🔎Knowledge📖 </h2>
</div>
<div align = "center">
    <p align = "justify">
        Muhammad Farhan Nazkham Albhiansyah
        <br>
    </p>
    <br>
    <h2 align="center"> 💻 I've Worked With  </h2>
    <p align = "center">
         <a href="https://skillicons.dev">
            <img style="margin: 10px"src="https://skillicons.dev/icons?i=java,kotlin,latex,swift,css,html,tensorflow,aws,haskell&perline=3"alt="My Skills"> 
        </a>
    </p>
    <h2 align="center"> 🛠️ I'm still learning or working on  </h2>
    <p align = "center">
         <a href="https://skillicons.dev">
            <img style="margin: 10px"src="https://skillicons.dev/icons?i=bash,linux,git,github,gitlab,py,sklearn,c,cpp,css,html,nodejs,react,vuejs,mysql,django&perline=8"alt="My Skills"> 
        </a>
    </p>
</div>
<br>
<br>
<br>

<div>
    <h2 align = "center"> 🏆 My Badges </h2>
</div>
<div align="center">
    <img align="center"src="badges/networking-basics.png" height="120px" width="120px"/>
    <img align="center"src="badges/ccna-introduction-to-networks.png" height="120px" width="120px"/>
    <img align="center" src="badges/ccna-switching-routing-and-wireless-essentials.1.png" height="120px" width="120px"/>
    <img align="center" src="badges/ccna-enterprise-networking-security-and-automation.png" height="120px" width="120px"/>
    <img align="center" src="badges/ccna-enterprise-networking-security-and-automation.png" height="120px" width="120px"/>
    <img align="center" src="badges/introduction-to-cybersecurity.png" height="120px" width="120px"/>
    <img src="https://tryhackme-badges.s3.amazonaws.com/tillend1x100.png" alt="Your Image Badge" />
</div>
<br>
<br>
<br>

<h2 align = "center"> 📉 GitHub Stats</h2>
<div> 
    <p align = "center">
<!--         <a href="https://github-readme-stats.vercel.app">
            <img width="49%" alt="Stats" src="https://github-readme-stats.vercel.app/api?username=Bhianesse&count_private=true&theme=neon&show_icons=true\&show=reviews,prs_merged,prs_merged_percentage\&rank_icon=github&hide_border=false">
        </a> -->
        <a href="https://github-readme-streak-stats.herokuapp.com">
            <img width="49%" alt="Streak Stats" src="https://github-readme-streak-stats.herokuapp.com/?user=Bhianesse&theme=neon&hide_border=false&date_format=%5BY%20%5DM%20j">
        </a><!--change language to japanese locale=jp-->
<!--         <a href="https://github.com/ryo-ma/github-profile-trophy">
            <img width="50%" align="left"alt="Trophy" src="https://github-profile-trophy.vercel.app/?username=Bhianesse&theme=radical&row=4&column=4">
            <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Bhianesse&hide_border=false&theme=neon&layout=compact&hide_progress=false&hide=jupyter%20notebook&langs_count=6" align="right" width = "41%">
        </a> -->
        <a href="https://github.com/ashutosh00710/github-readme-activity-graph">
            <img width="120%" alt="Stats" src="https://github-readme-activity-graph.vercel.app/graph?username=Bhianesse&theme=redical">
        </a>
        <a href="https://github.com/vn7n24fzkq/github-profile-summary-cards">
            <img width="120%" alt="GraphStats" src="http://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=Bhianesse&theme=2077">
    </p>
</div>
<br>
<br>
<h1 align="center"> My contributions game 🐍🎮</h1>

![](https://raw.githubusercontent.com/Bhianesse/Bhianesse/refs/heads/main/img/github-contribution-grid-snake-dark.svg#gh-dark-mode-only)
        <img src="https://raw.githubusercontent.com/Bhianesse/Bhianesse/refs/heads/main/img/github-contribution-grid-snake-dark.svg" width="500"/>
<br>

<h2 align ="center"> 📝 Contact me 📝</h2>
<br> 
<div align="center">
    <a href="https://github.com/Bhianesse" target="_blank">
        <img src=https://img.shields.io/badge/github-%2324292e.svg?&style=for-the-badge&logo=github&logoColor=white alt=github style="margin-bottom: 5px;">
    </a>
    <a href="https://trakteer.id/mybhianesse0" target="_blank">
        <img src=https://img.shields.io/badge/twitter-%2300acee.svg?&style=for-the-badge&logo=twitter&logoColor=white alt=twitter style="margin-bottom: 5px;">
    </a>
    <a href="https://saweria.co/mybhianesse0" target="_blank">
        <img src=https://img.shields.io/badge/linkedin-%231E77B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white alt=linkedin style="margin-bottom: 5px;">
    </a>
    <br>
    <img align="center"src = "https://i.pinimg.com/originals/e6/da/c1/e6dac1038095d76596e8b1bd9653f569.gif" width = "500">
</div>  
<br>
<div>
    <h2 align="center">Thank you for reading 🙋🏻‍♂️</h2>
    <div align="center">
        <img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/8c3c3cbd-7a4c-43da-b1cb-0a207be30230/dixdo22-7f42f7c1-1344-4843-8334-4cbbb22cd9bb.gif?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiIvZi84YzNjM2NiZC03YTRjLTQzZGEtYjFjYi0wYTIwN2JlMzAyMzAvZGl4ZG8yMi03ZjQyZjdjMS0xMzQ0LTQ4NDMtODMzNC00Y2JiYjIyY2Q5YmIuZ2lmIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.XjOv2uL_Lllb4IACFJE0-TG6ij6mhCeK99mwXcmcC88" width="500"/>
           <div align="center">
        <img src="https://viiip.kitashinsaku.com:443/0.php" width="500"/>
    </div>
</div>
<br> 
<br>

    
<h1 align="center">Support Me 🎧🎤  </h1>

<p align="center">
      <img src="https://i.pinimg.com/originals/cc/85/19/cc8519f9b3f798c87451e5c78b9e1629.gif">
⠀⠀⠀⠀⠀<img src="img/vocaloid/vocaloidchibi.png">
</p>


<a href="https://sociabuzz.com/mybhianesse0/tribe" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-red.png" alt="Buy Me A Coffee"  style="height: 60px !important;width: 217px !important;" align="center"></a>
